import './../pages/index.css';
import * as card from './card.js'
import * as utils from './utils.js'
import * as modal from './modal.js'
import * as validate from './validate.js'
import * as variables from './variables.js'
import * as api from './api.js'


export const data = {
  formSelector: '.popup__container',
  inputSelector: '.popup__input-field',
  submitButtonSelector: '.popup__button',
  inactiveButtonClass: 'popup__button_disabled',
  inputErrorClass: 'popup__input_type_error',
  errorClass: 'popup__error_visible'
};

// export let myProfileId
validate.enableValidation(data); 
//Пробовал создавать эту переменную в variables но все время возникала ошибка TypeError: Cannot set property myProfileId of #<Object> which has only a getter
//Object.defineProperty не помогло создание класса и там установка сетера тоже не сработала поэтому было принято решение переместить переменную в index.js

api.getProfile()
.then((result) => {
  setNetProfile(result);
  console.log(variables.myProfileId)
})
.catch ((err) => {
  console.log(err)
}); 

function setNetProfile(res) {
  variables.profileName.textContent = res.name;
  variables.profileDescription.textContent = res.about;
  variables.avatarImage.src = res.avatar;
  variables.myProfileId = String(res._id);
  // console.log(myProfileId)
}